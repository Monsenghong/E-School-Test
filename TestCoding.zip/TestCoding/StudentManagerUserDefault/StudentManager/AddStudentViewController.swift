//
//  ViewController.swift
//  StudentManager
//
//  Created by senghong on 10/2/22.
//

import UIKit

class AddStudentViewController: UITableViewController {

    let defauls = UserDefaults.standard
    var studentArray = ["Hong","Hak","Heng","Sen","Phol"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let item = defauls.array(forKey: "newStudent") as? [String]{
            
            studentArray = item
        }
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return studentArray.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "studentCell", for: indexPath)
        cell.textLabel?.text = studentArray[indexPath.row]
        return cell
    }
    @IBAction func addPressed(_ sender: UIBarButtonItem) {
        
        var textField = UITextField()
        
        let alert = UIAlertController(title:"Add New Student", message: "", preferredStyle: .alert)
        
        let action = UIAlertAction(title: "Add", style: .default, handler: {(action) in print(textField.text!)
            self.studentArray.append(textField.text!)
            
            self.defauls.set(self.studentArray, forKey: "newStudent")
            
            self.tableView.reloadData()
        })
        
        alert.addTextField(configurationHandler: {
            (alertTextField) in
            alertTextField.placeholder = "add student"
            print(alertTextField.text!)
            
            textField = alertTextField
        })
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
}

