//
//  Post.swift
//  NewsFeedScreen
//
//  Created by senghong on 12/2/22.
//

import Foundation
import UIKit


struct Post{
    
    var postTime:String?
    var caption:String
    var image:UIImage?
    var user: User?
    
    
    static func fetchPost()->[Post]{
        
        var post = [Post]()
        let user2 = User(profilePicture: UIImage(named: "lit1"),name: "Senghong", password: "1234", phone: "096 6666 6666")
        let user1 = User(profilePicture: UIImage(named: "lit1"),name: "Jilit", password: "1234", phone: "096 6666 6666")
        let post1 = Post(postTime: "55min",caption: "គីមីវិទ្យា",image: UIImage(named: "lit1"), user: user1)
        let post2 = Post(postTime: "1h",caption: "Feasibility Analysis: Testing an Opportun  Discuss the importance of defining a prospective business by writing a clear and concise business concept.",image: UIImage(named: "lit1"), user: user2)
        
        let post3 = Post(postTime: "20min",caption: "Feasibility Analysis: Testing an Opportun  Discuss the importance of defining a prospective business by writing a clear and concise business concept.",image: UIImage(named: "lit1"), user: user1)
        
        post.append(post1)
        post.append(post2)
        post.append(post3)
        return post
    }
    
}

struct User{
    var profilePicture: UIImage?
    var name:String
    var password:String
    var phone:String
    
}
