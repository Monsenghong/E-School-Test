//
//  NewFeedTableViewController.swift
//  NewsFeedScreen
//
//  Created by senghong on 12/2/22.
//

import UIKit

class NewFeedTableViewController: UITableViewController {

    
    var posts: [Post]?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        fectPost()
    }

    
    func fectPost(){
        
        posts = Post.fetchPost()
        tableView.reloadData()
    }
    
    
    
    
    

}

extension NewFeedTableViewController{
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let post = posts{
            
            return post.count
        }
        return 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "postCell", for: indexPath) as! TableViewCell
        
        cell.post = posts![indexPath.row]
        
        return cell
        
        
    }
}
