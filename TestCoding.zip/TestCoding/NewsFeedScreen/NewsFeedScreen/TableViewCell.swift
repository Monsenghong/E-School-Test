//
//  TableViewCell.swift
//  NewsFeedScreen
//
//  Created by senghong on 12/2/22.
//

import UIKit

class TableViewCell: UITableViewCell{

   
    @IBOutlet weak var postedTime: UILabel!
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var postImageView: UIImageView!

    @IBOutlet weak var userProfile: UIImageView!
    
    @IBOutlet weak var captionLabel: UILabel!
    
    
    var post: Post!{
        
        didSet{
            updateUI()
        }
    }
    
    func updateUI(){
        
        userProfile.makeRounded()
        
        userProfile.image = post.user?.profilePicture
        userName.text = post.user!.name
        postedTime.text = post.postTime
        captionLabel.text = post.caption
        postImageView.image = post.image
        
        
    }
    
   
    
    
}


extension UIImageView {

    func makeRounded() {
        
        self.layer.borderWidth = 1
        self.layer.masksToBounds = false
        self.layer.borderColor = UIColor.purple.cgColor
        self.layer.cornerRadius = self.frame.height / 2
        self.clipsToBounds = true
    }
}
