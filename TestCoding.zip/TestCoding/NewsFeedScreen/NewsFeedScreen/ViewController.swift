//
//  ViewController.swift
//  NewsFeedScreen
//
//  Created by senghong on 12/2/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

