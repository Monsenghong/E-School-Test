//
//  MyList+CoreDataClass.swift
//  CoreDataStudent
//
//  Created by senghong on 13/2/22.
//
//

import Foundation
import CoreData

@objc(MyList)
public class MyList: NSManagedObject {

}
