//
//  ViewController.swift
//  CoreDataStudent
//
//  Created by senghong on 13/2/22.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    private var models = [MyList]()
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    let tableView: UITableView = {
        
        let table = UITableView()
        table.register(UITableViewCell.self, forCellReuseIdentifier:"cell")
        
        return table
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        
        view.addSubview(tableView)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.frame = view.bounds
        
        
       
    }
    
    @IBAction func addPressed(_ sender: Any) {
//        let alert = UIAlertController(title: "New Student", message: "Enter new Student", preferredStyle: .alert)
//
//        alert.addTextField(configurationHandler: nil)
//        alert.addAction(UIAlertAction(title: "submit", style: .cancel, handler: { _ in
//            guard let field = alert.textFields?.first, let text = field.text, !text.isEmpty else {
//                return
//            }
//
//            self.createStudent(name: text)
//        }))
        
        
        var textField = UITextField()
        
        let alert = UIAlertController(title:"Add New Student", message: "", preferredStyle: .alert)
        
        let action = UIAlertAction(title: "Add", style: .default, handler: {(action) in print(textField.text!)
            self.createStudent(name:textField.text!)
            
            
            
            self.tableView.reloadData()
        })
        
        alert.addTextField(configurationHandler: {
            (alertTextField) in
            alertTextField.placeholder = "add student"
            print(alertTextField.text!)
            
            textField = alertTextField
        })
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
        
        print(models)
    }
    
   
    
   

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return models.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let model = models[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = model.name
        
        return cell
    }
    
    func getAllStudent(){
        
        do{
            let models = try context.fetch(MyList.fetchRequest())
            
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
        catch{
            
            
        }
        
        
    }
    
    func createStudent(name:String){
        
        let newStudent = MyList(context: context)
        
        newStudent.name = name
        newStudent.createdAt = Date()
        
        do{
            try context.save()
            
            getAllStudent()
        }catch{
            
            
        }
    }
    
    
    func deleteStudent(student: MyList){
        
        context.delete(student)
        
        do{
            try context.save()
            
        }catch{
            
            
        }

    }
    
    func updateStudent(student:MyList,newName:String){
        
        student.name = newName
      
        
        do{
            try context.save()
            
        }catch{
            
            
        }

    }
}

