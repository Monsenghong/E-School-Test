//
//  MyList+CoreDataProperties.swift
//  CoreDataStudent
//
//  Created by senghong on 13/2/22.
//
//

import Foundation
import CoreData


extension MyList {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<MyList> {
        return NSFetchRequest<MyList>(entityName: "MyList")
    }

    @NSManaged public var name: String?
    @NSManaged public var createdAt: Date?

}

extension MyList : Identifiable {

}
